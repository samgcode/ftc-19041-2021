package org.firstinspires.ftc.teamcode.auto.actions;

import org.firstinspires.ftc.teamcode.auto.RobotMap;

public class Action {

    public void init() {
        
    }
    
    public void loop() {
        
    }
    
    public boolean isFinished() {
        return false;
    }
    
    public void end() {
        
    }
}